require './student'
require './person'

student_a = Student.new("Happy", "Alampay")
puts student_a.full_name
