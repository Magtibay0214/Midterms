require './person'

class Student < Person
	attr_accessor :id_number
end
